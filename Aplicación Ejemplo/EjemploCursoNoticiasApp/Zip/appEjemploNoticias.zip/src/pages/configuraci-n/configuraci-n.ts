import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-configuraci-n',
  templateUrl: 'configuraci-n.html'
})
export class ConfiguraciNPage {

  constructor(public navCtrl: NavController) {
  }
  
}
