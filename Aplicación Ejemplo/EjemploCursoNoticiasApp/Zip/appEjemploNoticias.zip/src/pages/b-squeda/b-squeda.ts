import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-b-squeda',
  templateUrl: 'b-squeda.html'
})
export class BSquedaPage {

  constructor(public navCtrl: NavController) {
  }
  
}
