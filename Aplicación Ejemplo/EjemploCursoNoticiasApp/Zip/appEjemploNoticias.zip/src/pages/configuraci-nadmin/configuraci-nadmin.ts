import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-configuraci-nadmin',
  templateUrl: 'configuraci-nadmin.html'
})
export class ConfiguraciNAdminPage {

  constructor(public navCtrl: NavController) {
  }
  
}
